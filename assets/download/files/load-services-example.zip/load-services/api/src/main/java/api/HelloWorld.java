package api;

public interface HelloWorld {
    String sayHello();
    Long getTimestamp();
}
